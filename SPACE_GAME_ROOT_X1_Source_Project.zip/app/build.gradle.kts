plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.spacegame.rootx1"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.spacegame.rootx1"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
